# Aurora change log



## [1.3.3](https://github.com/qsyyke/vuepress-theme-aurora/compare/v1.3.2...v1.3.3) (2021-10-14)


### Bug Fixes

* **style:** fix the article list diagram and the top diagram ([9d755e7](https://github.com/qsyyke/vuepress-theme-aurora/commit/9d755e70e59d0db7c37b28402185544e9d9212ba))

