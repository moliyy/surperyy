import { h } from 'vue';
import { defineClientAppEnhance } from '@vuepress/client';
// import Aurora from './components/Aurora'
export default defineClientAppEnhance(({ app, router }) => {
    // app.component("Aurora",Aurora)

    /*
    你可以在此文件中，注册一个全局组件，但是需要使用到register-components插件
    使用方法，可以查看官方文档https://v2.vuepress.vuejs.org/zh/reference/plugin/register-components.html，和主题该部分的文档说明https://aurora.cco.vin/feature/registercom.html
    */ 
    
});
