declare const _default: import("@vuepress/client").ClientAppSetup;
export default _default;
