import './styles/index.scss';
import './styles/theme.style.css'
declare const _default: import("@vuepress/client").ClientAppEnhance;
export default _default;

