---
mood: [
  {
    title: 这是标题1,
    content: 这是心情内容1,
    avatar: https://ooszy.cco.vin/img/blog-public/avatar.jpg
  },
  {
      title: 这是标题2,
      content: 这是心情内容1这是心情内容1这是心情内容1这是心情内容1,
      avatar: https://ooszy.cco.vin/img/blog-public/avatar.jpg
  },
  {
      title: 这是标题1,
      content: ldfhksdf色调分离开化寺的开发速度快放假和三等分框架会三等分框架 sldfhksdf色调分离开化寺的开发速度快放假和三等分框架会三等分框架 sldfhksdf色调分离开化寺的开发速度快放假和三等分框架会,
      avatar: https://ooszy.cco.vin/img/blog-public/avatar.jpg
  },
  {
      title: 这是标题1,
      content: 三等分框架会三等分框架 sldfhksdf色调分离开化寺的开发速度快放,
      avatar: https://ooszy.cco.vin/img/blog-public/avatar.jpg
  },
  {
      title: 这是标题1,
      content: 化寺的开发速度快放假和三等分框架会三等分框架 sldfhksdf色调分离开化寺的开发速度快放假和三等分框架会三等分框架 sldfhksdf色调分离开化寺的开发速度快放假和三等分框架,
      avatar: https://ooszy.cco.vin/img/blog-public/avatar.jpg
  },
  {
      title: 这是标题1,
      content: 这是心情内容1,
      avatar: https://ooszy.cco.vin/img/blog-public/avatar.jpg
  },{
      title: 这是标题1,
      content: 这是心情内容1,
  },

]
---

# 心情一

ldfhksdf色调分离开化寺的开发速度快放假和三等分框架会三等分框架 sldfhksdf色调分离开化寺的开发速度快放假和三等分框架会三等分框架 sldfhksdf色调分离开化寺的开发速度快放假和三等分框架会



![image-20210901183045860](http://ooszy.cco.vin/img/blog-note/image-20210901183045860.png?x-oss-process=style/pictureProcess1)

![image-20210901183059457](http://ooszy.cco.vin/img/blog-note/image-20210901183059457.png?x-oss-process=style/pictureProcess1)

