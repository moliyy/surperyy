# 心情二



最使人疲惫的往往不是道路的遥远，而是你心中的郁闷；最使人颓废的往往不是前途的坎坷，而是你自信的丧失；最使人痛苦的往往不是生活的不幸，而是你希望的破灭；最使人绝望的往往不是挫折的打击，而是你心灵的死亡；所以我们凡事要看淡些，心放开一点，一切都会慢慢变好的。



![image-20210901183125990](http://ooszy.cco.vin/img/blog-note/image-20210901183125990.png?x-oss-process=style/pictureProcess1)

![image-20210901183139718](http://ooszy.cco.vin/img/blog-note/image-20210901183139718.png?x-oss-process=style/pictureProcess1)